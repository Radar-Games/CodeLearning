package Stuff;

public class Main 
{
	public static int[] numbers = new int[1000];
	
	public static int j = 0;
	
	public static a, b, c;
	
	public static void main(String[] args)
	{
		for (int i = 0; i <= 4000000; i++)
		{
			
		}
	}
}
