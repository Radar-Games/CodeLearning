import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.text.*;

class TextEditor extends JFrame
{void h()
{
    Has
}
}