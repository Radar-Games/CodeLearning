package Game;

import java.util.HashMap;

public class World 
{
	HashMap<String, Integer> 
}
