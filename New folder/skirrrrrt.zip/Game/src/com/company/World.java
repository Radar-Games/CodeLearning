package com.company;

public class World
{
    public static void checkSpace(int x, int y)
    {
        int locateX = x;
        int locateY = y;

        if(locateX == 0 && locateY == 1)
        {

        }
    }
}
